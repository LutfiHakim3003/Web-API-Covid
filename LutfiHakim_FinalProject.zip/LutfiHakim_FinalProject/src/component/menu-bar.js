class MenuBar extends HTMLElement {
    connectedCallback() {
        this.render();
    }

    render() {
        this.innerHTML = `
        <header>
        <nav class="navbar fixed-top navbar-expand-lg navbar-light navbar-dark bg-dark">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
              <a class="navbar-brand" href="#" style="margin: 0px 50px; vertical-align: top;">C<img src="https://image.flaticon.com/icons/png/512/2746/2746655.png" style="width: 20px;">VID-19</a>
              <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li class="nav-item">
                  <a class="nav-link" href="#covid-global">Global<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#covid-id">Indonesia</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#covid-prov">Provinsi</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#sumber-data">Referensi</a>
                </li>
              </ul>
            </div>
          </nav>
          </header>
        `;
    }
}

customElements.define("menu-bar", MenuBar);