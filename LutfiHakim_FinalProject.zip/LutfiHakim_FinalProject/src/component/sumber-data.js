class SumberData extends HTMLElement {
    connectedCallback() {
        this.render();
    }

    render() {
        this.innerHTML = `
        <div class="card">
            <h4 class="card-header">Referensi Data Pembaruan Informasi Covid-19 di Indonesia</h4>
            <ul class="list-group" style="border-radius: 0px; border: 0px">
              <li class="list-group-item d-flex justify-content-between align-items-center">Covid19 Portal Republik Indonesia
                <a href="https://covid19.go.id/peta-sebaran"><span class="badge badge-primary badge-pill">detail</span></a>
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-center">Kementerian Kesehatan Republik Indonesia
                <a href="https://infeksiemerging.kemkes.go.id/"><span class="badge badge-primary badge-pill">detail</span></a>
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-center">Kawal Covid 19
                <a href="https://kawalcovid19.id/"><span class="badge badge-primary badge-pill">detail</span></a>
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-center">Corona Virus 19 API Herokuapp
                <a href="http://coronavirus-19-api.herokuapp.com/"><span class="badge badge-primary badge-pill">detail</span></a>
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-center">Covid-19 API
                <a href="https://api.covid19api.com"><span class="badge badge-primary badge-pill">detail</span></a>
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-center">Covid-19 Mathdro.id
                <a href="https://covid19.mathdro.id/api"><span class="badge badge-primary badge-pill">detail</span></a>
              </li>
            </ul>
        </div>
        `;
    }
}

customElements.define("sumber-data", SumberData);