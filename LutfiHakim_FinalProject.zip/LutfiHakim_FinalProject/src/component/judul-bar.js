class JudulBar extends HTMLElement {
    connectedCallback() {
        this.render();
    }

    render() {
        this.innerHTML = `
        <div class="jumbotron jumbotron-fluid bg-info">
            <div class="container">
                <h1 class="display-4">STATISTIK COVID-19</h1>
                <p class="lead"><b>Data Global dan Indonesia</b></p>
            </div>
        </div>
        `;
    }
}

customElements.define("judul-bar", JudulBar);