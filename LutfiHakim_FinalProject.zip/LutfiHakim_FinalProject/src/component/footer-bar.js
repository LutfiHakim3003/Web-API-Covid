class FooterBar extends HTMLElement {
    connectedCallback(){
        this.render();
    }

    render(){
        this.innerHTML =`
        <p>Copyright &copy; 2020<br>
        Made with <i class="em em-heart"></i> by Lutfi hakim</p>
        `;
    }
}

customElements.define("footer-bar", FooterBar);