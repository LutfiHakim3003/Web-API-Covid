class ProvinsiBar extends HTMLElement {
    connectedCallback() {
        this.render();
    }

    render(){
        this.innerHTML =`
        <div class="card">
            <h4 class="card-header">Persebaran Kasus di Tiap Provinsi Indonesia</h4>
            <div class="card-body">
              <div class="card-text">
                <div class="container">
                  <table class="table table-striped">
                    <thead>
                      <tr class="bg-info">
                        <th>No.</th>
                        <th>Provinsi</th>
                        <th>Positif</th>
                        <th>Sembuh</th>
                        <th>Meninggal</th>
                      </tr>
                    </thead>
                    <tbody id="listDataProv"></tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        `;
    }
}

customElements.define("provinsi-bar", ProvinsiBar);