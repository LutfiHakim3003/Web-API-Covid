import "regenerator-runtime";
import "bootstrap/dist/css/bootstrap.min.css";
import "./styles/style.css";
import "./component/menu-bar.js";
import "./component/judul-bar.js";
import "./component/provinsi.js";
import "./component/sumber-data.js";
import "./component/footer-bar.js";
import main from "./view/main.js";

main();