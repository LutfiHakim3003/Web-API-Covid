function main() {

    const updateDate = document.querySelector('.date');

    const getDataGlobal = () => {
        const dataGlobal = 'http://coronavirus-19-api.herokuapp.com/all';
        fetch(`${dataGlobal}`).then(response => {
            return response.json();
        })
        .then(data => {
            const confirmed = document.querySelector('#data-kasus');
            const deaths = document.querySelector('#data-mati');
            const recovered = document.querySelector('#data-sembuh');
            
            let dataRate = data.cases;
            let dataDeaths = data.deaths;
            let dataRecovered = data.recovered;

            confirmed.innerHTML = dataRate;
            deaths.innerHTML = dataDeaths;
            recovered.innerHTML = dataRecovered;
            updateDate.innerHTML = formatDate();

            const ratedCase = document.querySelector('#rerataCase');
            let rateCase = (dataRate/dataRate) * 100;
            ratedCase.innerHTML = Math.round(rateCase);

            const ratedDeaths = document.querySelector('#rerataMati');
            let rateDeaths = (dataDeaths/dataRate) * 100;
            ratedDeaths.innerHTML = Math.round(rateDeaths);
            
            const ratedRecovered = document.querySelector('#rerataSembuh');
            let rateRocovered = (dataRecovered/dataRate) * 100;
            ratedRecovered.innerHTML = Math.round(rateRocovered);
        })
        .catch(error => {
            showResponseMessage(error);
        });
    };

    const getDataID = () => {
        const dataCovidID = 'http://coronavirus-19-api.herokuapp.com/countries';
        const kasusID = document.querySelector('#kasus-id');
        const kasusIdToday = document.querySelector('#kasus-id-today');
        const matiID = document.querySelector('#mati-id');
        const matiIdToday = document.querySelector('#mati-id-today');
        const sembuhID = document.querySelector('#sembuh-id');
        const aktif = document.querySelector('#rawat-id');
        const aktifToday = document.querySelector('#aktif-today');

        fetch(`${dataCovidID}`).then(response => {
            return response.json();
        }).then(data => {
            let json = data;

            if(json.length > 0){
                for(let i = 0; i < json.length; i++){
                    let dataNegara = json[i];
                    let namaNegara = dataNegara.country;

                    if(namaNegara === 'Indonesia') {
                        kasusID.innerHTML = dataNegara.cases;
                        matiID.innerHTML = dataNegara.deaths;
                        sembuhID.innerHTML = dataNegara.recovered;
                        aktif.innerHTML = dataNegara.active;

                        kasusIdToday.innerHTML = dataNegara.todayCases;
                        matiIdToday.innerHTML = dataNegara.todayDeaths;
                        aktifToday.innerHTML = dataNegara.todayCases;
                    }
                }
            }
        })

        fetch("https://api.covid19api.com/summary").then(response => {
            return response.json();
        }).then(data => {
            if(data.error) {
                showResponseMessage(data.message);
            } else {
                renderSembuh(data.Countries);
            }
        }).catch(error => {
            showResponseMessage(error);
        })
    };

    const renderSembuh = (Countries) => {
        const sembuhIdToday = document.querySelector('#sembuh-id-today');
        let json = Countries;
        if(json.length > 0){
            for(let i = 0; i < json.length; i++) {
                let dtNegara = json[i];
                let nmNegara = dtNegara.Country;

                if(nmNegara === "Indonesia") {
                    sembuhIdToday.innerHTML = dtNegara.NewRecovered;
                }
            }
        }
    };

    const getDataProv = () => {
        const dataProv = "https://indonesia-covid-19.mathdro.id/api/provinsi";

        fetch(`${dataProv}`).then(response => {
            return response.json();
        }).then(responseJson => {
            if(responseJson.error) {
                showResponseMessage(responseJson.message);
            } else {
                renderAllProv(responseJson.data);
            }
        }).catch(error => {
            showResponseMessage(error);
        })
    };

    const renderAllProv = (data) => {
        let json = data;
        if(json.length > 0){
            var temp = "";
            json.forEach((u, index) => {
                temp += "<tr>";
                temp += `<td> ${index + 1} </td>`;
                temp += `<td> ${u.provinsi} </td>`;
                temp += `<td> ${u.kasusPosi} </td>`;
                temp += `<td> ${u.kasusSemb} </td>`;
                temp += `<td> ${u.kasusMeni} </td>`;
            })
            document.getElementById('listDataProv').innerHTML = temp;
        }
    };

    function formatDate() {
        var today = new Date();
        var hari = String(today.getDate()).padStart(2, '0');
        var bulan = String(today.getMonth() + 1).padStart(2, '0');
        var tahun = today.getFullYear();

        today = hari + '/' + bulan + '/' + tahun;
        return today;
    };

    const showResponseMessage = (message = "Cek Koneksi Internet anda!!!") => {
        alert(message);
    };

    document.addEventListener("DOMContentLoaded", () => {
        getDataGlobal();
        getDataID();
        getDataProv();
    });
}

export default main;